# https://mittkak.nu/v1/menus/next-week
import json
import requests

# allting funkar hyffsat men det blir drygt och krångligt att lägga till så allt funkar som det ska
daysArray = ["monday", "tuesday", "wednesday", "thursday", "friday"]

def check(DAY):
    for i in daysArray:
        if (i == DAY):
            return True
    return False

def sendOrder(usernm, passwrd, menuID, monday,thusday,wendesday,thursday,friday):

    sendOrderUrl = "https://mittkak.nu/v1/orders"
    data = {
        "friday": friday,
        "menu": menuID,
        "monday": monday,
        "thursday": thursday,
        "tuesday": thusday,
        "wednesday": wendesday
    }
    send = requests.post(sendOrderUrl, data, auth=(usernm, passwrd)) # byt nu sen innan jag glömmer !!!!!!!!!!!!!!!!!!!!!1
    return send

def showFood(usernm, passwrd): 
    nextWeekurl = "https://mittkak.nu/v1/menus/next-week"
    r = requests.get(url=nextWeekurl, auth=(usernm, passwrd)) # BYTTT SENN !!!!!!!!!!!!!!!!!
    x = json.loads(r.text)
    dag = 1
    menyID = ""
    veckOrder = []

    try:
        menyID = x["id"]
        print("meny id",menyID)
    except:
        print("lyckades inte få meny id")

    for mat in x:
        try:
            if (check(mat)):
                dagOrder = []
                print(str(dag) + ". Dag", mat, end="\n\n")
                dishes = x[mat]["dishes"]
                matC = 1
                for dish in dishes:
                    print(str(matC) + ". " +  dish["name"])
                    matC += 1
                    dagOrder.append(dish["id"])
                inpt = int(input("Mat för denna dag(siffra(0 för ingen mat)): "))
                if (inpt == 0):
                    veckOrder.append("")
                else:
                    try:
                        veckOrder.append(dagOrder[inpt-1])
                    except:
                        print("fel format? skriv siffra")
                        exit()
                dag += 1
                print("\n")
        except:
            print(str(dag) + " - " + mat + " - Ingen mat/fel")
    print("Du har valt")
    for i in veckOrder:
        print(i,end="  ")
    choice = input("Skicka order? (ja/nej) ")
    if (choice.lower() == "ja"):
        return sendOrder(usernm,passwrd, menyID, veckOrder[0], veckOrder[1], veckOrder[2], veckOrder[3], veckOrder[4])
    elif (choice.lower == "nej"):
        print("ok")
        exit()